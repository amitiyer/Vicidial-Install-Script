// vicidial_chat.js
//
// Copyright (C) 2015  Joe Johnson, Matt Florell <vicidial@gmail.com>    LICENSE: AGPLv2
//
// Used by manager_chat_actions, this file contains all Javascript functions that grab 
// information off of the web page and utilize AJAX to pass data to manager_chat_actions.php,
// which will respond with data used to update the manager chat interface.
//
// Builds:
// 150612-2334 - First build
// 151219-0719 - moved into manager_chat_interface.php
//
