<?php
# new_manager_chat_form.php
# 
# Copyright (C) 2015  Joe Johnson, Matt Florell <vicidial@gmail.com>    LICENSE: AGPLv2
#
# This page is for managers (level 8 or higher) to chat with live agents
#
# changes:
# 150608-2041 - First Build
# 151219-0718 - Added translation code where missing
# 151219-1858 - Depricated
#
?>
